const mongoose = require("mongoose");

const moodEntrySchema = new mongoose.Schema(
  {
    moodLevel: {
      type: Number, // 1 to 5 from slider
      required: true,
    },
    moodLabel: {
      type: String, // "Sad", "Happy", etc.
      required: true,
    },
    note: {
      type: String,
      default: "",
    },
    contentType: {
      type: String, // "quote", "task", "music"
      default: "quote",
    },
    generatedContent: {
      type: String, // what we showed the user
      default: "",
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model("MoodEntry", moodEntrySchema);
