const express = require("express");
const router = express.Router();
const { getMoodHistory, addMoodEntry } = require("../controllers/moodController");

router.get("/", getMoodHistory);
router.post("/", addMoodEntry);

module.exports = router;
