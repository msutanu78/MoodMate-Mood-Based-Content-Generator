const MoodEntry = require("../models/MoodEntry");

// GET /api/moods - get mood history
const getMoodHistory = async (req, res) => {
  try {
    const entries = await MoodEntry.find().sort({ createdAt: -1 });
    res.json(entries);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server error" });
  }
};

// POST /api/moods - save a new mood entry
const addMoodEntry = async (req, res) => {
  try {
    const { moodLevel, moodLabel, note, contentType, generatedContent } = req.body;

    const newEntry = await MoodEntry.create({
      moodLevel,
      moodLabel,
      note,
      contentType,
      generatedContent,
    });

    res.status(201).json(newEntry);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server error" });
  }
};

module.exports = {
  getMoodHistory,
  addMoodEntry,
};
