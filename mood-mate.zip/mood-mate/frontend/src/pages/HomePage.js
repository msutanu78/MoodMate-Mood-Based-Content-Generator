// frontend/src/pages/HomePage.js
import React, { useState } from "react";
import axios from "axios";
import MoodSlider from "../components/MoodSlider";
import Avatar from "../components/Avatar";
import ContentDisplay from "../components/ContentDisplay";
import MoodJournal from "../components/MoodJournal";
import MoodHistory from "../components/MoodHistory";

const API_URL = "http://localhost:5000/api/moods";

function HomePage() {
  const [mood, setMood] = useState(3);
  const [moodLabel, setMoodLabel] = useState("Okay");
  const [lastContentType, setLastContentType] = useState("");
  const [lastGeneratedContent, setLastGeneratedContent] = useState("");

  // get logged-in user (if any)
  const savedUser = localStorage.getItem("user");
  const user = savedUser ? JSON.parse(savedUser) : null;

  const handleMoodChange = (value) => {
    setMood(value);
    if (value <= 1) setMoodLabel("Very Sad");
    else if (value === 2) setMoodLabel("Sad");
    else if (value === 3) setMoodLabel("Okay");
    else if (value === 4) setMoodLabel("Happy");
    else setMoodLabel("Very Happy");
  };

  const handleContentGenerated = (type, content) => {
    setLastContentType(type);
    setLastGeneratedContent(content);
  };

  const handleSaveEntry = async (note) => {
    try {
      await axios.post(API_URL, {
        moodLevel: mood,
        moodLabel,
        note,
        contentType: lastContentType,
        generatedContent: lastGeneratedContent,
      });
      alert("Mood entry saved!");
    } catch (error) {
      console.error("Error saving mood entry", error);
      alert("Failed to save mood entry");
    }
  };

  return (
    <div className="card">
      {/* Top heading + mood badge */}
      <div className="card-header-row">
        <div>
          <h1>MoodMate 🧠</h1>
          {user ? (
            <p className="muted-text">
              Welcome back, <strong>{user.name}</strong> 👋 Track how you feel and
              get mood-matched content.
            </p>
          ) : (
            <p className="muted-text">
              Track your mood, get personalized quotes & tasks, and reflect in your
              journal.
            </p>
          )}
        </div>
        <div className="mood-badge">
          <span className="mood-badge-label">Current mood</span>
          <span className="mood-badge-value">{moodLabel}</span>
        </div>
      </div>

      {/* Avatar */}
      <Avatar mood={mood} />

      {/* 1. Mood slider */}
      <section className="section-block">
        <h2 className="section-title">1. How are you feeling?</h2>
        <p className="section-description">
          Use the slider to set your current mood. The avatar reacts with you.
        </p>
        <MoodSlider mood={mood} setMood={handleMoodChange} />
      </section>

      {/* 2. Generated content */}
      <section className="section-block">
        <h2 className="section-title">2. Mood-based boost</h2>
        <p className="section-description">
          Get a quote, task, or suggestion tailored to how you feel right now.
        </p>
        <ContentDisplay mood={mood} onContentGenerated={handleContentGenerated} />
      </section>

      {/* 3. Journal */}
      <section className="section-block">
        <h2 className="section-title">3. Mood journal</h2>
        <p className="section-description">
          Write a short note about your day or what’s on your mind, then save it.
        </p>
        <MoodJournal onSave={handleSaveEntry} />
      </section>

      <hr />

      {/* 4. History */}
      <section className="section-block">
        <h2 className="section-title">Mood history</h2>
        <p className="section-description">
          Review your previous moods, notes, and generated content over time.
        </p>
        <MoodHistory />
      </section>
    </div>
  );
}

export default HomePage;
