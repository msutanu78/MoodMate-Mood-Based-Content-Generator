// frontend/src/App.js
import React from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import HomePage from "./pages/HomePage";
import LoginPage from "./pages/LoginPage";
import RegisterPage from "./pages/RegisterPage";

function App() {
  // Read user from localStorage (if logged in)
  const savedUser = localStorage.getItem("user");
  const user = savedUser ? JSON.parse(savedUser) : null;

  const handleLogout = () => {
    // Clear auth data
    localStorage.removeItem("user");
    localStorage.removeItem("token");
    // Simple redirect to login page
    window.location.href = "/login";
  };

  return (
    <Router>
      <div className="app-container">
        {/* Header (wraps navbar) */}
        <header className="site-header">
          <nav className="navbar">
            <div className="logo-group">
              <h2 className="logo">MoodMate 🧠</h2>
              <span className="logo-subtitle">Mood-based content companion</span>
            </div>

            <div className="nav-links">
              <Link to="/" className="nav-link">
                Home
              </Link>

              {user ? (
                <>
                  <span className="nav-link user-pill">
                    Hi, <strong>{user.name}</strong>
                  </span>
                  <button
                    type="button"
                    className="nav-link nav-button logout-button"
                    onClick={handleLogout}
                  >
                    Logout
                  </button>
                </>
              ) : (
                <>
                  <Link to="/login" className="nav-link">
                    Login
                  </Link>
                  <Link to="/register" className="nav-link nav-button">
                    Sign Up
                  </Link>
                </>
              )}
            </div>
          </nav>
        </header>

        {/* Main content */}
        <main className="main-content">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/register" element={<RegisterPage />} />
          </Routes>
        </main>

        {/* Footer */}
        <footer className="site-footer">
          <p>MoodMate © {new Date().getFullYear()} · Take care of your mind 💜</p>
        </footer>
      </div>
    </Router>
  );
}

export default App;
