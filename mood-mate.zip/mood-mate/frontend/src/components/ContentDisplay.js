// frontend/src/components/ContentDisplay.js
import React, { useState } from "react";

const quotes = {
  low: [
    "It's okay to feel sad. This too shall pass.",
    "You are stronger than you think.",
  ],
  mid: [
    "Keep going, you're doing fine!",
    "Small steps still move you forward.",
  ],
  high: [
    "You're glowing today!",
    "Share your happiness with someone!",
  ],
};

const tasks = {
  low: ["Write down 3 things you're grateful for.", "Take a 5-minute walk."],
  mid: ["Message a friend and say hi.", "Organize your desk."],
  high: ["Start that passion project!", "Do something kind for someone."],
};

// 🎵 New: music suggestions
const music = {
  low: [
    "Soft chill playlist: search 'lofi beats to relax' on YouTube.",
    "Try a calm piano playlist on Spotify to slow down.",
  ],
  mid: [
    "Focus mode: search 'deep focus' or 'lofi coding' playlists.",
    "Try some acoustic or indie chill to match your mood.",
  ],
  high: [
    "Energy up! Try 'Happy Hits' or 'Feel-Good Pop' playlists.",
    "Dance break: play your favourite upbeat song and move for 3 minutes.",
  ],
};

function ContentDisplay({ mood, onContentGenerated }) {
  const [contentType, setContentType] = useState("quote");
  const [content, setContent] = useState("");

  const getMoodLevel = () => {
    if (mood <= 2) return "low";
    if (mood === 3) return "mid";
    return "high";
  };

  const generateContent = () => {
    const level = getMoodLevel();
    let selected = "";

    if (contentType === "quote") {
      const arr = quotes[level];
      selected = arr[Math.floor(Math.random() * arr.length)];
    } else if (contentType === "task") {
      const arr = tasks[level];
      selected = arr[Math.floor(Math.random() * arr.length)];
    } else if (contentType === "music") {
      const arr = music[level];
      selected = arr[Math.floor(Math.random() * arr.length)];
    }

    setContent(selected);
    onContentGenerated(contentType, selected);
  };

  return (
    <div>
      <div className="content-picker-row">
        <label className="content-label">
          Content type
          <select
            value={contentType}
            onChange={(e) => setContentType(e.target.value)}
            className="content-select"
          >
            <option value="quote">Quote</option>
            <option value="task">Task / Challenge</option>
            <option value="music">Music suggestion 🎵</option>
          </select>
        </label>

        <button onClick={generateContent} className="primary-button">
          Generate
        </button>
      </div>

      {content && (
        <div className="generated-content fade-in-up">
          <strong>{contentType.toUpperCase()}:</strong>
          <p>{content}</p>
        </div>
      )}
    </div>
  );
}

export default ContentDisplay;
