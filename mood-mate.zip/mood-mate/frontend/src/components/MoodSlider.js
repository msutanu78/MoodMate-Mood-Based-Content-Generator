import React from "react";

const moodLabels = {
  1: "Very Sad",
  2: "Sad",
  3: "Okay",
  4: "Happy",
  5: "Very Happy",
};

function MoodSlider({ mood, setMood }) {
  return (
    <div className="mood-slider">
      <div className="mood-slider-header">
        <span className="mood-label">Mood</span>
        <span className="mood-value">
          {mood} – {moodLabels[mood]}
        </span>
      </div>

      <input
        type="range"
        min="1"
        max="5"
        value={mood}
        onChange={(e) => setMood(Number(e.target.value))}
        className="mood-range"
      />

      <div className="mood-scale">
        <span>😢</span>
        <span>😐</span>
        <span>🤩</span>
      </div>
    </div>
  );
}

export default MoodSlider;
