import React, { useState } from "react";

function MoodJournal({ onSave }) {
  const [note, setNote] = useState("");

  const handleSave = () => {
    onSave(note);
    setNote("");
  };

  return (
    <div style={{ margin: "15px 0" }}>
      <h3>Mood Journal</h3>
      <textarea
        rows="3"
        style={{ width: "100%" }}
        placeholder="Write about how you feel..."
        value={note}
        onChange={(e) => setNote(e.target.value)}
      />
      <button onClick={handleSave} style={{ marginTop: "5px" }}>
        Save Entry
      </button>
    </div>
  );
}

export default MoodJournal;
