import React from "react";

function getEmoji(mood) {
  if (mood <= 1) return "😭";
  if (mood === 2) return "😢";
  if (mood === 3) return "😐";
  if (mood === 4) return "😊";
  return "🤩";
}

function Avatar({ mood }) {
  return (
    <div className="avatar-container">
      <div className="avatar-glow">
        <span className="avatar-emoji">{getEmoji(mood)}</span>
      </div>
    </div>
  );
}

export default Avatar;
