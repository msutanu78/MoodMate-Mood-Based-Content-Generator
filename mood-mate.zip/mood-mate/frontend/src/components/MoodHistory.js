import React, { useEffect, useState } from "react";
import axios from "axios";

const API_URL = "http://localhost:5000/api/moods";

function MoodHistory() {
  const [history, setHistory] = useState([]);

  const fetchHistory = async () => {
    try {
      const res = await axios.get(API_URL);
      setHistory(res.data);
    } catch (error) {
      console.error("Error fetching history", error);
    }
  };

  useEffect(() => {
    fetchHistory();
  }, []);

  return (
    <div style={{ margin: "15px 0" }}>
      <h3>Mood History</h3>
      {history.length === 0 && <p>No entries yet.</p>}
      <ul>
        {history.map((entry) => (
          <li key={entry._id} style={{ marginBottom: "10px" }}>
            <strong>{entry.moodLabel}</strong> ({entry.moodLevel}) –{" "}
            {new Date(entry.createdAt).toLocaleString()}
            {entry.note && <div>Note: {entry.note}</div>}
            {entry.generatedContent && (
              <div>Content: {entry.generatedContent}</div>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default MoodHistory;
